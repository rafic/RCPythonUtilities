#
# Takes the following args
#    - root of src files, e.g. for c:\\src\\com\\rc\Test.java w fully qualified name of com.rc.Test it is 'c:\\src'
#    - root of src files, e.g. for c:\\src\\com\\... where all classes have their base package as 'com' it is 'c:\\src'
#    - Fully qualified class/package name to be copied over
#
# and copies the java source file from src to dst; watch the console for failure output (e.g. src file not found, ...)
#

import glob
import os
import re
import sys
import string
import StringIO
import time
import types
import tempfile
import xml.dom.minidom
import shutil
import zipfile
#import find
import md5
import subprocess
import shlex, subprocess
import traceback
import copy

import RCToolkit
import RCToolkitVCPerforce
import RCToolkitDict
import RCToolkitLog
import RCToolkitIUserInteraction

# clear console
RCToolkit.clearConsole()

if (sys.argv.__len__() == 4):
   try:
      root_src = sys.argv[1] 
      root_dst = sys.argv[2]
      full_class_name = sys.argv[3]
   except IndexError:
      RCToolkitLog.log ("Please provide the following arguments and in the following order:")
      RCToolkitLog.log ("   - root of src files, e.g. for c:\\src\\com\\rc\Test.java w fully qualified name of com.rc.Test it is 'c:\\src'")
      RCToolkitLog.log ("   - root of dst files, e.g. for c:\\src\\com\\... where all classes have their base package as 'com' it is 'c:\\src'")
      RCToolkitLog.log ("   - Fully qualified class/package name to be copied over")
      sys.exit(1)
else:
   RCToolkitLog.log ("Please provide the following arguments and in the following order:")
   RCToolkitLog.log ("   - root of src files, e.g. for c:\\src\\com\\rc\Test.java w fully qualified name of com.rc.Test it is 'c:\\src'")
   RCToolkitLog.log ("   - root of dst files, e.g. for c:\\src\\com\\... where all classes have their base package as 'com' it is 'c:\\src'")
   RCToolkitLog.log ("   - Fully qualified class/package name to be copied over")
   sys.exit(1)

if (root_src.endswith('\\') or root_src.endswith('/')):
   root_src = root_src[:-1]
if (root_dst.endswith('\\') or root_dst.endswith('/')):
   root_dst = root_dst[:-1]
full_class_name = '\\' + full_class_name.replace('.', '\\') + '.java'
src = root_src + full_class_name
dst = root_dst + full_class_name[:-(len(full_class_name) - full_class_name.rindex('\\') - 1)]  # rfind / rindex w exception
if not os.path.exists(dst):
   os.makedirs(dst)

#print 'root src ' + root_src
#print 'root dst ' + root_dst
#print 'full class name ' + full_class_name
#print 'src ' + src
#print 'dst ' + dst
##full_class_name[:-len(full_class_name) - full_class_name.rindex('\\')]
#print full_class_name
#print len(full_class_name)
#print full_class_name.rindex('\\')
#print len(full_class_name) - full_class_name.rindex('\\')
#print full_class_name[:-(len(full_class_name) - full_class_name.rindex('\\'))]

#   shutil.copy2(line, line.replace(ws_path_branch_from, ws_path_branch_to))
#c:\RC\Dev\code\tools\JavaDoc\DoctorJ\doctorj-5.1.2WNew-JavaCC-PMD\net\sourceforge\pmd\lang\java\ast
#return 'C:\\p4ws' + data.replace('//', '/').replace('/', '\\')
#
# C:\RC\Dev\code\tools\JavaDoc\DoctorJ\temp\pmd-src-5.0.5\src\main\java
# C:\RC\Dev\code\tools\JavaDoc\DoctorJ\doctorj-5.1.2WNew-JavaCC-PMD
# net.sourceforge.pmd.util.StringUtil
shutil.copy2(src, dst)
print '... Done copying'
# C:\RC\Dev\code\tools\JavaDoc\DoctorJ\temp\pmd-src-5.0.5\src\main\java\net\sourceforge\pmd\util
# C:\RC\Dev\code\tools\JavaDoc\DoctorJ\doctorj-5.1.2WNew-JavaCC-PMD\\net\\sourceforge\\pmd\\util\\StringUtil.java
