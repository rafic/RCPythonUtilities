
import glob
import os
import re
import sys
import string
import StringIO
import time
import types
import tempfile
import xml.dom.minidom
import shutil
import zipfile
#import find
import md5
import subprocess
import shlex, subprocess
import traceback
import copy
import shutil
import RCToolkit
import RCToolkitDict
import RCToolkitLog

################################################################################
# RC for sub-stringing
#>>> x = "Hello World!"
#>>> x[2:]
#'llo World!'
#>>> x[:2]
#'He'
#>>> x[:-2]
#'Hello Worl'
#>>> x[-2:]
#'d!'
#>>> x[2:-2]
#'llo Worl'
################################################################################



#Variables declared inside the class definition, but not inside a method are class or static variables
# for 'p4 opened -s -C rcohen-lt2 -c  508461' output format
#EChangeType = RCToolkit.enum(ADD=' - add change', MOD=' - edit change', DEL=' - delete change')
# for 'p4 describe 508461' output format
EChangeType = RCToolkit.enum(ADD=' add', MOD=' edit', DEL=' delete')



#----------------------------------------------------------------------------
# Read the files associated with the perforce changelist# arg and output it into an output list
def readChangeList(changelist_nr):
   assert isinstance(changelist_nr, (str))
   RCToolkitLog.log ("Reading change list ["+changelist_nr+"] ...")

   # output format for a pending CL:
   #C:\Users\RCohen>p4 describe 508461
   #Change 508461 by rafi@rcohen-lt2 on 2013/08/28 18:09:01 *pending*
   #
   #        E2E
   #
   #Affected files ...
   #
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/000_DataLoader_LoadData_Full.tst#1 edit
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/203_validate_Bins_present.tst#1 edit
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/205_validate_Cards_present.tst#1 edit
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/dummy.txt#1 add
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/testsuite.config#1 delete
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/200_incr_dataload/000_DataLoader_LoadData_Incr.tst#1 edit
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/200_incr_dataload/201_validate_terminals_2_present.tst#1 edit
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/200_incr_dataload/205_validate_Cards_present.tst#1 edit
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/200_incr_dataload/207_validate_Accounts_present.tst#1 edit
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/200_incr_dataload/testsuite.config#1 edit
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/files/Full/limits.csv#1 edit
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/files/Incremental/terminals.csv#1 edit
   #
   #
   #C:\Users\RCohen>p4 opened -s -C rcohen-lt2 -c  508461
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/000_DataLoader_LoadData_Full.tst - edit change 508461 by rafi@rcohen-lt2
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/203_validate_Bins_present.tst - edit change 508461 by rafi@rcohen-lt2
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/205_validate_Cards_present.tst - edit change 508461 by rafi@rcohen-lt2
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/dummy.txt - add change 508461 by rafi@rcohen-lt2
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/testsuite.config - delete change 508461 by rafi@rcohen-lt2
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/200_incr_dataload/000_DataLoader_LoadData_Incr.tst - edit change 508461 by rafi@rcohen-lt2
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/200_incr_dataload/201_validate_terminals_2_present.tst - edit change 508461 by rafi@rcohen-lt2
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/200_incr_dataload/205_validate_Cards_present.tst - edit change 508461 by rafi@rcohen-lt2
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/200_incr_dataload/207_validate_Accounts_present.tst - edit change 508461 by rafi@rcohen-lt2
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/200_incr_dataload/testsuite.config - edit change 508461 by rafi@rcohen-lt2
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/files/Full/limits.csv - edit change 508461 by rafi@rcohen-lt2
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/files/Incremental/terminals.csv - edit change 508461 by rafi@rcohen-lt2
   #
   #C:\Users\RCohen>
   #
   # output format for a submitted CL:
   #C:\Users\RCohen>p4 describe 506582
   #Change 506582 by rafi@rcohen-lt2 on 2013/08/15 18:31:50
   #
   #        SLX Ticket #/Bug Tracking #: D001-00-010642
   #
   #        Description: Adjustments to JUnit test classes so as to have them all run successfully
   #
   #        Code Change: As per need so as to have JUnit classes match DB changes
   #
   #        Previous Behavior: Some JUnit tests have failed
   #
   #        New Behavior: JUnit tests all run successfully
   #
   #        Database Changes: N/A
   #
   #        Documentation Updates: N/A
   #
   #        Change Reason: Per task
   #
   #        Testing: Yes
   #
   #        Reviewed by: Francois J.
   #
   #Affected files ...
   #
   #... //depot/release/termapp/framework/5/x/tests/junit/postilion/realtime/termappframework/crypto/impl/rg7000/TestDesMacBdk.java#5 edit
   #... //depot/release/termapp/framework/5/x/tests/junit/postilion/realtime/termappframework/crypto/impl/rg7000/TestTaFwDesRG7000Bdk.java#5 edit
   #... //depot/release/termapp/framework/5/x/tests/junit/postilion/realtime/termappframework/dbloader/IncrementalFileLoaderTest.java#3 edit
   #... //depot/release/termapp/framework/5/x/tests/junit/postilion/realtime/termappframework/table/CommunicationsTableTest.java#4 edit
   #... //depot/release/termapp/framework/5/x/tests/junit/postilion/realtime/termappframework/table/EmvAidParametersTableTest.java#4 edit
   #... //depot/release/termapp/framework/5/x/tests/junit/postilion/realtime/termappframework/table/EmvPublicKeysTableTest.java#4 edit
   #... //depot/release/termapp/framework/5/x/tests/junit/postilion/realtime/termappframework/table/MsgForMerchantTableTest.java#4 edit
   #... //depot/release/termapp/framework/5/x/tests/junit/postilion/realtime/termappframework/TermAppTerminalInfoTest.java#9 edit
   #
   #Differences ...
   #
   #==== //depot/release/termapp/framework/5/x/tests/junit/postilion/realtime/termappframework/crypto/impl/rg7000/TestDesMacBdk.java#5 (text) ====
   #
   #9c9
   #<  * Copyright (C) 2005                                                                         *
   #---
   #...
   #
   #C:\Users\RCohen>




   # for 'p4 opened -s -C rcohen-lt2 -c  508461' output format
   #cmd = 'p4 opened -s -C rcohen-lt2 -c ' + changelist_nr
   #args = shlex.split(cmd)
   #output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE).communicate()
   #RCToolkitLog.log ('   output [' + output + ']')
   #RCToolkitLog.log ('   error  [' + error  + ']')

   # for 'p4 describe 508461' output format
   cmd = 'p4 describe ' + changelist_nr
   args = shlex.split(cmd)
   output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE).communicate()
#  RCToolkitLog.log ('   output [' + output + ']') for submitted CL there might be a lot of output while P4 spells out each change in each file
   RCToolkitLog.log ('   error  [' + error  + ']')
   if (error.__len__() > 0):
      RCToolkitLog.log ('   Something is wrong - see error above, aborting:')
      sys.exit(1)

   list_desc_cl_output_lines = output.split('\r\n')
   # trim prefix and suffix lines
   preserve_start = -1
   for i in range(len(list_desc_cl_output_lines)):
      if (preserve_start == -1):
         if (list_desc_cl_output_lines[i].rstrip() == 'Affected files ...'):
            # i += 2 does not work, as when hitting the 'for' above it gets restored to its pre +=2 value
            preserve_start = i + 2
            continue
      else:
         if (i <= preserve_start):
            continue
         if (list_desc_cl_output_lines[i].rstrip() == ''):
            list_desc_cl_output_lines = list_desc_cl_output_lines[preserve_start:i]
            break
   RCToolkitLog.log ("... Done reading change list ["+changelist_nr+"]")
   return list_desc_cl_output_lines



#----------------------------------------------------------------------------
# Read the files associated with the perforce CL# arg and output it into an output list
def getLatest(dict_):
   assert isinstance(dict_, (dict))
   RCToolkitLog.log ("P4 Getting latest ...")
   for key in dict_:
      if (key == EChangeType.MOD):
         for line in dict_[key]:
            cmd = 'p4 -c rcohen-lt2 get ' + line
            args = shlex.split(cmd)
            output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE).communicate()
            # e.g. output: //depot/release/termapp/framework/5/2.patches/tests/testharness/testcases/hotcard/Session_hotfile1.dat.log#1 - added as C:\p4ws\depot\release\termapp\framework\5\2.patches\tests\testharness\testcases\hotcard\Session_hotfile1.dat.log
            if (output.find(' - added as C:\\') > -1):
               continue
            # e.g. Err: //depot/release/termapp/framework/5/2.patches/tests/testharness/testcases/incremental_load/successfull/Session_term.xml.log - file(s) up-to-date.
            if (error.find(' - file(s) up-to-date') > -1):
               continue
            RCToolkitLog.log ('Something is wrong, aborting:')
            RCToolkitLog.log ("P4-GET: Error  [" + error  + ']')
            RCToolkitLog.log ("P4-GET: output [" + output + ']')
            sys.exit(1)
   RCToolkitLog.log ("... Done getting latest")



#----------------------------------------------------------------------------
# Read the files associated with the perforce changelist# arg and output it into an output list
def apply(dict_):
   assert isinstance(dict_, (dict))
   RCToolkitLog.log ("P4 applying changes ...")
   for key in dict_:
      if (key == EChangeType.ADD):
         for line in dict_[key]:
            cmd = 'p4 -c rcohen-lt2 add ' + line
            args = shlex.split(cmd)
            output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE).communicate()

            if (output.find('TODO') > -1):
               continue
            if (error.find('TODO') > -1):
               continue
            RCToolkitLog.log ('Something is wrong, aborting:')
            RCToolkitLog.log ("P4-ADD: Error  [" + error  + ']')
            RCToolkitLog.log ("P4-ADD: output [" + output + ']')
            sys.exit(1)

      if (key == EChangeType.MOD):
         for line in dict_[key]:
            cmd = 'p4 -c rcohen-lt2 edit ' + line
            args = shlex.split(cmd)
            output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE).communicate()

            # e.g. P4-EDIT: output: //depot/release/termapp/framework/5/2.patches/tests/testharness/testcases/incremental_load/successfull/Session_term.xml.log#1 - opened for edit
            if (output.find(' - opened for edit') > -1):
               continue
            # and if opened for edit already: P4-EDIT: output: //depot/release/termapp/framework/5/2.patches/tests/testharness/testcases/incremental_load/successfull/Session_term.xml.log#1 - currently opened for edit
            if (output.find(' - currently opened for edit') > -1):
               continue
            RCToolkitLog.log ('Something is wrong, aborting:')
            RCToolkitLog.log ("P4-EDIT: Error  [" + error  + ']')
            RCToolkitLog.log ("P4-EDIT: output [" + output + ']')
            sys.exit(1)

      if (key == EChangeType.DEL):
         for line in dict_[key]:
            cmd = 'p4 -c rcohen-lt2 delete ' + line
            args = shlex.split(cmd)
            output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE).communicate()

            if (output.find('TODO') > -1):
               continue
            if (error.find('TODO') > -1):
               continue
            RCToolkitLog.log ('Something is wrong, aborting:')
            RCToolkitLog.log ("P4-DEL: Error  [" + error  + ']')
            RCToolkitLog.log ("P4-DEL: output [" + output + ']')
            sys.exit(1)
   RCToolkitLog.log ("... Done applying changes")



#----------------------------------------------------------------------------
# Read the files associated with the perforce changelist# arg and output it into an output list
def replacePathFromDepotToWS(dict_input):
   assert isinstance(dict_input, (dict))
   dict_output = {
      EChangeType.ADD: [],
      EChangeType.MOD: [],
   }
   for key in dict_input:
      if (key == EChangeType.DEL):
         continue
      for line in dict_input[key]:
         #dict_output[key].append('C:\\p4ws' + line.replace('//', '/').replace('/', '\\'))
         dict_output[key].append(pathFromDepotToWS(line))

   return dict_output



#----------------------------------------------------------------------------
# Read the files associated with the perforce changelist# arg and output it into an output list
def pathFromDepotToWS(data):
   assert isinstance(data, (str))
   return 'C:\\p4ws' + data.replace('//', '/').replace('/', '\\')



#----------------------------------------------------------------------------
# iterates over the input list, where each entry looks like one of these
#    //depot/release/termapp/framework/5/x/source/delphi/common/mTermAppPluginManager.pas - edit change 499221 by rafi@rcohen-lt2
#    //depot/release/termapp/framework/5/x/source/delphi/common/pfTermAppEditBaseDlg.dfm - delete change 499221 by rafi@rcohen-lt2
#    //depot/release/termapp/framework/5/x/source/delphi/cards_cfg/html_help/System.stp - add change 499221 by rafi@rcohen-lt2
# and load that content into a dict/map, while truncating the ' - ...' suffix,
# so the end result looks like this
#   output_dict[EChangeType.ADD]
#      //depot/release/termapp/framework/5/x/source/delphi/cards_cfg/html_help/System.stp
#      ...
#   output_dict[EChangeType.DEL]
#      //depot/release/termapp/framework/5/x/source/delphi/common/pfTermAppEditBaseDlg.dfm
#      ...
#   output_dict[EChangeType.MOD]
#      //depot/release/termapp/framework/5/x/source/delphi/common/mTermAppPluginManager.pas
#      ...
def reorgChangesListByChangeType(input_list):
   #pass
   # map/dictionary example: tel = {'jack': 4098, 'sape': 4139}
   output_dict = {
      EChangeType.ADD: [],
      EChangeType.DEL: [],
      EChangeType.MOD: [],
   }
   assert isinstance(input_list, (list))

   # for 'p4 opened -s -C rcohen-lt2 -c  508461' output format
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/dummy.txt - add change 508461 by rafi@rcohen-lt2
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/testsuite.config - delete change 508461 by rafi@rcohen-lt2
   #//depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/200_incr_dataload/000_DataLoader_LoadData_Incr.tst - edit change 508461 by rafi@rcohen-lt2
   #
   #   for line in input_list:
   #      index = line.find(EChangeType.ADD)
   #      if index > -1:
   #         output_dict[EChangeType.ADD].append(line[:index])
   #         continue
   #      index = line.find(EChangeType.DEL)
   #      if index > -1:
   #         output_dict[EChangeType.DEL].append(line[:index])
   #         continue
   #      index = line.find(EChangeType.MOD)
   #      if index > -1:
   #         output_dict[EChangeType.MOD].append(line[:index])
   #         continue

   # for 'p4 describe 508461' output format
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/dummy.txt#1 add
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/100_full_dataload/testsuite.config#1 delete
   #... //depot/retail/E2E/automated/testharness/Loaders/tests/testcases/woolworths/store0001/200_incr_dataload/000_DataLoader_LoadData_Incr.tst#1 edit
   #
   for line in input_list:
      if (line.endswith(EChangeType.ADD)):
         output_dict[EChangeType.ADD].append(line[line.find('/'):line.rfind('#')])
         continue
      if (line.endswith(EChangeType.DEL)):
         output_dict[EChangeType.DEL].append(line[line.find('/'):line.rfind('#')])
         continue
      if (line.endswith(EChangeType.MOD)):
         output_dict[EChangeType.MOD].append(line[line.find('/'):line.rfind('#')])
         continue

   # for key in d: will simply loop over the keys in the dictionary, rather than the keys and values. To loop over both key and value you can use for key, value in d.iteritems():
   #for key in output_dict:
   #   RCToolkitLog.log('   ' + key)
   #   for line in output_dict[key]:
   #      RCToolkitLog.log('      [' + line + ']')
   return output_dict



#----------------------------------------------------------------------------
def copyFiles(dict_, depot_path_branch_src, depot_path_branch_dst):
   assert isinstance(dict_, (dict))
   assert isinstance(depot_path_branch_src, (str))
   assert isinstance(depot_path_branch_dst, (str))
   ws_path_branch_from = pathFromDepotToWS(depot_path_branch_src)
   ws_path_branch_to   = pathFromDepotToWS(depot_path_branch_dst)
   for key in dict_:
      if (key == EChangeType.DEL):
         continue
      for line in dict_[key]:
         shutil.copy2(line, line.replace(ws_path_branch_from, ws_path_branch_to))



#readChangeList ('506582')

