
import glob
import os
import re
import sys
import string
import StringIO
import time
import types
import tempfile
import xml.dom.minidom
import shutil
import zipfile
#import find
import md5
import subprocess
import shlex, subprocess
import traceback
import copy
import msvcrt


#----------------------------------------------------------------------------
# Prompts user for an input and returns input to caller
def getInput(prompt, confirm = False):
   assert isinstance(prompt, (str))
   
   input = ''
   while (input == ''):
      input = raw_input(prompt)
      if (input == ''):
         continue
      while (confirm):
         print('Press Enter to confirm, ESC to re-input, any other key to abort:')
         confirmation = msvcrt.getch()#raw_input('Enter to confirm, any other key(s) followed by Enter to re-input')
         
         if (confirmation == '\r'): # i.e. ENTER
            return input
         
         if (confirmation == chr(27).encode()): # i.e. ESC
            input = ''
            break
         
         #print(confirmation)
         sys.exit(1)
      
