#
# Takes the following args
#    - root of src files, e.g. for c:\\src\\com\\rc\Test.java w fully qualified name of com.rc.Test it is 'c:\\src'
#    - root of src files, e.g. for c:\\src\\com\\... where all classes have their base package as 'com' it is 'c:\\src'
#    - Fully qualified class/package name to be copied over
#
# and copies the java source file from src to dst; watch the console for failure output (e.g. src file not found, ...)
#

import glob
import os
import re
import sys
import string
import StringIO
import time
import types
import tempfile
import xml.dom.minidom
import shutil
import zipfile
#import find
import md5
import subprocess
import shlex, subprocess
import traceback
import copy

import RCToolkit
import RCToolkitVCPerforce
import RCToolkitDict
import RCToolkitLog
import RCToolkitIUserInteraction

# clear console
RCToolkit.clearConsole()

if (sys.argv.__len__() == 3):
   try:
      src = sys.argv[1] # C:\RC\Dev\code\tools\JavaDoc\DoctorJ\doctorj-5.1.2WNew-JavaCC-PMD\net\sourceforge\pmd\ast
      dst = sys.argv[2] # C:\RC\Dev\code\tools\JavaDoc\DoctorJ\temp\pmd-src-4.3\src\net\sourceforge\pmd\ast
   except IndexError:
      RCToolkitLog.log ("Please provide the following arguments and in the following order:")
      RCToolkitLog.log ("   - src files dir")
      RCToolkitLog.log ("   - dst files dir")
      sys.exit(1)
else:
   RCToolkitLog.log ("Please provide the following arguments and in the following order:")
   RCToolkitLog.log ("   - src files dir")
   RCToolkitLog.log ("   - dst files dir")
   sys.exit(1)

path_separator = os.path.normcase('/')
src = src.replace('\\', path_separator)
dst = dst.replace('\\', path_separator)
if not (src.endswith(path_separator)):
   src = src + path_separator
if not (dst.endswith(path_separator)):
   dst = dst + path_separator

print 'SRC ['+src+']'
print 'DST ['+dst+']'
   
list_existing_dst_filenames = []
list_existing_dst_fullfilenames = []
   
# rename all existing files
print '------------------- Renaming existing old classes W newer siblings and copying over newer siblings -------------------'        
for path,dirs,files in os.walk(dst):
   for file in files:
      list_existing_dst_filenames.append(file)
      list_existing_dst_fullfilenames.append(os.path.join(path,file))
      #filename = os.path.join(path,fn)
      #os.rename(filename, filename + '.orig')
      #os.rename(filename, filename[:-5])
      #print '['+filename+']['+filename[:-5]+']'
      #os.rename(filename, filename[:-5])
list_existing_dst_filenames.sort()      
list_existing_dst_fullfilenames.sort()
   
for path,dirs,files in os.walk(src):
   for file in files:
      if (file in list_existing_dst_filenames):
         if not (os.path.exists(dst+file + '.old+Wnew')):
            os.rename(dst+file, dst+file + '.old+Wnew')
         shutil.copy2(os.path.join(path,file), dst)
         list_existing_dst_fullfilenames.remove(dst+file)
         print '+ SRC file [' + file + '] copied to dst and orig remaned to *.old+Wnew'
      else:
         print '- SRC file [' + file + '] not copied to dst as does not exist in it'
      #filename = os.path.join(path,file)
      #print filename
      #print filename[filename.rindex(path_separator) + 1:]  # rfind / rindex w exception
      #filename = filename[filename.rindex(path_separator) + 1:]  # rfind / rindex w exception
      #print ('V' if os.path.exists(dst+filename) else 'x') + '   ' + filename + '   ' + dst+filename
print '------------------- Renaming existing old classes W/O newer siblings -------------------'        
for full_file_name in list_existing_dst_fullfilenames:
   if (os.path.exists(full_file_name)):
      if not (os.path.exists(full_file_name + '.old-WOnew')):
         os.rename(full_file_name, full_file_name + '.old-WOnew')
         print '- DST file [' + full_file_name[(full_file_name.rindex(path_separator) + 1):] + '] does not have a sibling in src and renamed to *.old-WOnew'
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        