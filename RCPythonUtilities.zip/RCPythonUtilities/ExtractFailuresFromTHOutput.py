
import glob
import os
import re
import sys
import string
import StringIO
import time
import types
import tempfile
import xml.dom.minidom
import shutil
import zipfile
#import find
import md5
import subprocess
import shlex, subprocess
import traceback
import copy

import RCToolkit
import RCToolkitVCPerforce
import RCToolkitDict
import RCToolkitLog


def log(line_txt, line_nr):
   assert isinstance(line_txt, (str))
   assert isinstance(line_nr , (int))
   #'{:>30}'.format('right aligned')
   RCToolkitLog.log('{:>10}'.format(str(line_nr)) + ': ' + line_txt)

# clear console
RCToolkit.clearConsole()

try:
   th_output_file_name = sys.argv[1] # 'C:\RC\$Temp\SpringBok\TAF-TAISO-TestSuites-Tweaks\output.txt'
except IndexError:
   RCToolkitLog.log ("Please provide the path to the file, which contains TH output to be parsed")
   sys.exit(1)

ttl_suites = 0
ttl_test_cases = 0
# map/dictionary example: tel = {'jack': 4098, 'sape': 4139}
dict_failures = {}
line_nr = 0
#array = []
collecting_details = False
#ins = open( th_output_file_name, "r" )
#for line in ins:
#    array.append( line )
test_suite_raw = ''
test_case_raw  = ''
output_test_file = True
with open(th_output_file_name, "r") as f:
   while(True):
      line = f.readline()
      line_nr += 1

      if (line.__len__() == 0): # when reading file in this way EOF is indicated by an empty string
         break

      line = line.rstrip()

      if (line.__len__() == 0   # filter out empty lines
          or
          line.startswith("`")  # filter out comments
          or
          line.startswith("'")  # filter out comments
          or
          line.find(' completed suite:') > -1
          or
          line.find(' end test case [') > -1
          or
          line.find(' errors       : ') > -1 #line == ' errors       : 0'
          or
          line.find(' failures     : ') > -1): #line == ' failures     : 0'
         continue;

      #18:33:12.584 starting suite:
      #             C:\temp\RC\RCTemp\tests\TestHarness\testcases
      #18:33:21.232 completed suite:
      #             C:\temp\RC\RCTemp\tests\TestHarness\testcases
      if (line.find(' starting suite:' ) > -1):
          #or
          #line.find(' completed suite:') > -1):
         #log(line, line_nr)
         #line = f.readline().rstrip()
         #log(line, line_nr)
         test_suite_raw = f.readline()
         line_nr += 1
         ttl_suites += 1
         continue
      
      
      #18:33:14.589 start test case [Turn_Trace_On.tst]
      if (line.find(' start test case ' ) > -1):
         #log(line, line_nr)
         test_case_raw = line
         output_test_file = True # new test case -> reset flag in case failures are identified during its run
         ttl_test_cases += 1
         continue


      if (collecting_details):
         if (line.strip() == '[err]'):
            continue
         #18:34:10.218 send       1100 from TAIsoAASap1                               [ ]
         #18:34:10.222 receive    0100 at dummySink                                   [x]
         #                                                                                   +--------------------
         #          >> field [26]                                                            |
         #                not expected                                                       | somewhere
         #                actual   : [12]                                                    | here ...
         #                                                                                   |
         #18:34:10.730 send       0110 from dummySink                                 [ ]    +--------------------
         #         
         if (line[0] == ' '
             or
             line[0] == '['
             or
             line.endswith('[x]')
             or
             #13:52:59.831 start test case [203_validate_Bins_present.tst]
             #13:53:01.518 approximate parse time: 1.69 s
             #
             #13:53:01.518 espcommand                                                     [!]            <--------------
             #
             #          >> Could not connect to Esp Command entity [SQL]
             #
             #[inf]        Reconnected 0 times due to the following: The attempt, by SAP
             #             '<unnamed>', to connect to the remote host EspHost on port 50010
             #             was refused. The remote host is either not listening on the
             #             specified port, or is refusing the connection for some other
             #             reason.
             #
             #[err]        Could not connect to Esp Command entity [SQL]
             #
             #          >> Could not connect to Esp Command entity [SQL]
             #
             #13:53:23.953 end test case [203_validate_Bins_present.tst]
             #13:53:23.953 approximate processing time (includes parse time): 24.12 s
             line.endswith('[!]')):
            log(line, line_nr)
            
            #if (line.startswith('          >> field [')
            #    or
            #    line.startswith('          >> expected')):
            if (line.startswith('          >> ')):
               if (dict_failures.has_key(line[13:])):
                  dict_failures[line[13:]] += 1
               else:
                  dict_failures[line[13:]] = 1
            continue

         collecting_details = False
         continue

      if (line.endswith('[x]')
          or
          line.endswith('[!]')
          or
            #[inf]        Sending eSpCommand [ROWCOUNT: "select * from esp_bins WHERE 
            #             card_name = 'VisaCredit' and and bin = 40 and esp_bins.timestamp 
            #             = '__ACTIVE_TS_TERM_CONFIG__' "] to [SQL]
            #
            #[err]        Command response [[Microsoft][ODBC SQL Server Driver][SQL 
            #             Server]Incorrect syntax near the keyword 'and'.] from [SQL] does 
            #             not match [1]
            #
            #[inf]        ...
           line.startswith('[err]')):
         if (output_test_file):
            output_test_file = False
            RCToolkitLog.log(test_suite_raw.strip() + '\\' + test_case_raw[test_case_raw.find('[') + 1:-1])
         log(line, line_nr)
         collecting_details = True
         continue

      if (line.lower().find('failure') > -1
          or
          line.lower().find('error'  ) > -1):
         log(line, line_nr)
         continue

ttl_msg_not_received = 0
for key in sorted(dict_failures.iterkeys()):
   if (key.startswith('message [') and key.find('] not received within [') > -1):
      ttl_msg_not_received += dict_failures[key]

RCToolkitLog.log('**************************************************************')         
RCToolkitLog.log('Total suites    : ' + str(ttl_suites))
RCToolkitLog.log('Total test cases: ' + str(ttl_test_cases))
#RCToolkitLog.log(dict_failures)
for key in sorted(dict_failures.iterkeys()):
   if (key.startswith('field [')):
      error = 'Field ' + '{:>10}'.format(key[7:-1]) + ' mismatch'
   elif (key.startswith('message [') and key.find('] not received within [') > -1):
      continue
   else:
      error = "'"+key+"'"
   print "%s issue identified %s time(s)" % (error, '{:>4}'.format(str(dict_failures[key])))
if (ttl_msg_not_received > 0):
   print "'message [...] not received within [...] ..' issue identified %s time(s):" % ('{:>4}'.format(str(ttl_msg_not_received)))
   for key in sorted(dict_failures.iterkeys()):
      if (key.startswith('message [') and key.find('] not received within [') > -1):
         print "   '%s' issue identified %s time(s)" % (key, '{:>4}'.format(str(dict_failures[key])))

#field [7.127.42]
#'{:<30}'.format('left aligned')


