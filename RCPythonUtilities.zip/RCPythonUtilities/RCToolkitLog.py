

import glob
import os
import re
import sys
import string
import StringIO
import time
import types
import tempfile
import xml.dom.minidom
import shutil
import zipfile
#import find
import md5
import subprocess
import shlex, subprocess
import traceback
import copy

################################################################################
# RC for sub-stringing
#>>> x = "Hello World!"
#>>> x[2:]
#'llo World!'
#>>> x[:2]
#'He'
#>>> x[:-2]
#'Hello Worl'
#>>> x[-2:]
#'d!'
#>>> x[2:-2]
#'llo Worl'
################################################################################


#http://stackoverflow.com/questions/1549801/differences-between-isinstance-and-type-in-python
#   Using type():
#      import types
#      if type(a) is types.DictType:
#          do_something()
#      if type(b) in types.StringTypes():
#          do_something_else()
#
#   Using isinstance():
#      if isinstance(a, dict):
#          do_something()
#      if isinstance(b, str) or isinstance(b, unicode):
#          do_something_else()
# To summarize the contents of other (already good!) answers, isinstance caters for inheritance (an instance of a derived class is an instance of a base class, too),
# while checking for equality of type does not (it demands identity of types and rejects instances of subtypes, AKA subclasses).
#----------------------------------------------------------------------------
def logDict(dict_):
   assert isinstance(dict_, (dict))
   # for key in d: will simply loop over the keys in the dictionary, rather than the keys and values. To loop over both key and value you can use for key, value in d.iteritems():
   log('['+str(len(dict_))+'] entries:')
   for key in dict_:
      if isinstance(dict_[key], list): # value is a list
         #log('['+str(len(dict_))+'] entries:')
         log('   Key [' + key + '], ['+str(len(dict_[key]))+'] entries')
         for line in dict_[key]:
            log('      [' + line + ']')
      else:
         log('   Key [' + key + '], Val ['+str(dict_[key])+']')

#----------------------------------------------------------------------------
def logList(list_):
   assert isinstance(list_, (list))
   log('['+str(len(list_))+'] entries')
   for line in list_:
      log('   [' + line + ']')



#----------------------------------------------------------------------------
def log(data):
   if isinstance(data, dict):
       logDict(data)
       return
   if isinstance(data, list):
       logList(data)
       return
   assert isinstance(data, (str))
   print data


