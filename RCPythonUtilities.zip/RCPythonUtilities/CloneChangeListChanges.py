
import glob
import os
import re
import sys
import string
import StringIO
import time
import types
import tempfile
import xml.dom.minidom
import shutil
import zipfile
#import find
import md5
import subprocess
import shlex, subprocess
import traceback
import copy

# http://stackoverflow.com/questions/11403932/python-attributeerror-module-object-has-no-attribute-serial
# Q.
#    import serial
#    and yet
#    AttributeError: 'module' object has no attribute 'Serial'
# A.
#   You're importing the module, not the class. So, you must write: from serial import serial
import RCToolkit
import RCToolkitVCPerforce
import RCToolkitDict
import RCToolkitLog
import RCToolkitIUserInteraction
################################################################################
# RC for sub-stringing
#>>> x = "Hello World!"
#>>> x[2:]
#'llo World!'
#>>> x[:2]
#'He'
#>>> x[:-2]
#'Hello Worl'
#>>> x[-2:]
#'d!'
#>>> x[2:-2]
#'llo Worl'
################################################################################


# clear console
RCToolkit.clearConsole()

if (sys.argv.__len__() == 4):
   try:
      change_nr              = sys.argv[1]
      depot_path_branch_from = sys.argv[2]
      depot_path_branch_to   = sys.argv[3]
   except IndexError:
      RCToolkitLog.log ("Please provide the following arguments and in the following order:")
      RCToolkitLog.log ("   - Change # of change to be cloned")
      RCToolkitLog.log ("   - From branch Perforce path")
      RCToolkitLog.log ("   - To branch Perforce path")
      sys.exit(1)
elif (sys.argv.__len__() == 1):
   change_nr              = RCToolkitIUserInteraction.getInput('Please enter CL number: ', True)
   depot_path_branch_from = RCToolkitIUserInteraction.getInput('Please enter FROM branch Perforce path: ', True)
   depot_path_branch_to   = RCToolkitIUserInteraction.getInput('Please enter TO branch Perforce path: ', True)
else:
   RCToolkitLog.log ("Please provide the following arguments and in the following order:")
   RCToolkitLog.log ("   - Change # of change to be cloned")
   RCToolkitLog.log ("   - From branch Perforce path")
   RCToolkitLog.log ("   - To branch Perforce path")
   sys.exit(1)

list_orig_change = RCToolkitVCPerforce.readChangeList(change_nr) # //depot/release/termapp/framework/5/x/
#RCToolkitLog.log(list_orig_change)
dict_orig_change = RCToolkitVCPerforce.reorgChangesListByChangeType(list_orig_change);
#RCToolkitLog.log(dict_orig_change)
dict_cloned_change = RCToolkitDict.replace(dict_orig_change, depot_path_branch_from, depot_path_branch_to);
#RCToolkitLog.log(dict_cloned_change)
RCToolkitVCPerforce.getLatest(dict_cloned_change)
RCToolkitVCPerforce.apply(dict_cloned_change)
dict_orig_change_w_ws_paths = RCToolkitVCPerforce.replacePathFromDepotToWS(dict_orig_change)
RCToolkitLog.log(dict_orig_change_w_ws_paths)
dict_cloned_change_w_ws_paths = RCToolkitVCPerforce.replacePathFromDepotToWS(dict_cloned_change)
RCToolkitLog.log(dict_cloned_change_w_ws_paths)
RCToolkitVCPerforce.copyFiles(dict_orig_change_w_ws_paths, depot_path_branch_from, depot_path_branch_to)


#output_list_499605 = Toolkit.readChangeList('499605') # //depot/release/termapp/framework/5/2.patches/
##for line in output_list_499221:
##   RCToolkitLog.log(line)
##for line in output_list_499605:
##   RCToolkitLog.log(line)
#output_dict_499221 = Toolkit.reorgChangesListByChangeType(output_list_499221);
#output_dict_499605 = Toolkit.reorgChangesListByChangeType(output_list_499605);
#
#output_dict_499221 = Toolkit.stripPrefix(output_dict_499221, len('//depot/release/termapp/framework/5/x/'));
#output_dict_499605 = Toolkit.stripPrefix(output_dict_499605, len('//depot/release/termapp/framework/5/2.patches/'));
#
#Toolkit.subtract(output_dict_499605, output_dict_499221)
## for key in d: will simply loop over the keys in the dictionary, rather than the keys and values. To loop over both key and value you can use for key, value in d.iteritems():
#RCToolkitLog.log('Only in 499605 (5/2.patches)')
#for key in output_dict_499605:
#   RCToolkitLog.log('   ' + key)
#   for line in output_dict_499605[key]:
#      RCToolkitLog.log('      [' + line + ']')
#RCToolkitLog.log('Only in 499221 (5/x)')
#for key in output_dict_499221:
#   RCToolkitLog.log('   ' + key)
#   for line in output_dict_499221[key]:
#      RCToolkitLog.log('      [' + line + ']')

























