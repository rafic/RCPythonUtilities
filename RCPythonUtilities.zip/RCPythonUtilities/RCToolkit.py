
import glob
import os
import re
import sys
import string
import StringIO
import time
import types
import tempfile
import xml.dom.minidom
import shutil
import zipfile
#import find
import md5
import subprocess
import shlex, subprocess
import traceback
import copy

################################################################################
# RC for sub-stringing
#>>> x = "Hello World!"
#>>> x[2:]
#'llo World!'
#>>> x[:2]
#'He'
#>>> x[:-2]
#'Hello Worl'
#>>> x[-2:]
#'d!'
#>>> x[2:-2]
#'llo Worl'
################################################################################



#----------------------------------------------------------------------------
def enum(**enums):
   return type('Enum', (), enums)

#----------------------------------------------------------------------------
# clear console
def clearConsole():
   os.system('cls') #on windows
   #os.system('clear') # on linux / os x
