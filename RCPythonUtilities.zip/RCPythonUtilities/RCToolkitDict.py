
import glob
import os
import re
import sys
import string
import StringIO
import time
import types
import tempfile
import xml.dom.minidom
import shutil
import zipfile
#import find
import md5
import subprocess
import shlex, subprocess
import traceback
import copy
import RCToolkit
import RCToolkitLog

################################################################################
# RC for sub-stringing
#>>> x = "Hello World!"
#>>> x[2:]
#'llo World!'
#>>> x[:2]
#'He'
#>>> x[:-2]
#'Hello Worl'
#>>> x[-2:]
#'d!'
#>>> x[2:-2]
#'llo Worl'
################################################################################



#----------------------------------------------------------------------------
# iterates over the input dict, where each entry is a list containing entries, which look like one of these
#   output_dict[EChangeType.ADD]
#      //depot/release/termapp/framework/5/x/source/delphi/cards_cfg/html_help/System.stp
#      ...
#   output_dict[EChangeType.DEL]
#      //depot/release/termapp/framework/5/x/source/delphi/common/pfTermAppEditBaseDlg.dfm
#      ...
#   output_dict[EChangeType.MOD]
#      //depot/release/termapp/framework/5/x/source/delphi/common/mTermAppPluginManager.pas
#      ...
# and for each entry strips the first prefix_len chars
# so the end result looks like this (assuming prefix_len == len('//depot/release/termapp/framework/5/x/')
#   output_dict[EChangeType.ADD]
#      source/delphi/cards_cfg/html_help/System.stp
#      ...
#   output_dict[EChangeType.DEL]
#      source/delphi/common/pfTermAppEditBaseDlg.dfm
#      ...
#   output_dict[EChangeType.MOD]
#      source/delphi/common/mTermAppPluginManager.pas
#      ...
def stripPrefixFromEntries(input_dict, prefix_len):
   assert isinstance(input_dict, (dict))
   assert isinstance(prefix_len, (int))
   output_dict = {}

   for key in input_dict:
      output_dict[key] = []
      for line in input_dict[key]:
         output_dict[key].append(line[prefix_len:])

   #output_dict.sort()
   for key in output_dict:
      #RCToolkit.log('   ' + key)
      output_dict[key].sort()
      #for line in output_dict[key]:
      #   RCToolkit.log('      [' + line + ']')
   return output_dict



#----------------------------------------------------------------------------
# modify the input dicts by removing common entries from both
def subtract(dict_l, dict_r):
   assert isinstance(dict_l, (dict))
   assert isinstance(dict_r, (dict))
   # as a dict cannot have items removed while iterating over it, create a copy and iterate over that copy
   dict_l_copy = copy.deepcopy(dict_l)
   for key in dict_l_copy:
      for line in dict_l_copy[key]:
         try:
            dict_r[key].index(line) # if not found then exception
            #RCToolkit.log ('removing ['+line+']')
            dict_l[key].remove(line)
            dict_r[key].remove(line)
         except:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            traceback.print_exception(exc_type, exc_value, exc_traceback)



#----------------------------------------------------------------------------
# modify the input dicts by removing common entries from both
def replace(dict_input, str_old, str_new):
   assert isinstance(dict_input, (dict))
   assert isinstance(str_old, (str))
   assert isinstance(str_new, (str))
   dict_output = {}

   for key in dict_input:
      dict_output[key] = []
      for line in dict_input[key]:
         dict_output[key].append(line.replace(str_old, str_new))

   return dict_output

